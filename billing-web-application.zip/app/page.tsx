"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Printer, Plus, Trash2, Save, FolderOpen, Eye } from "lucide-react"

interface Product {
  id: string
  description: string
  size: string
  media: string
  ssOrFb: string
  colour: string
  quantity: number
  rate: number
  amount: number
}

interface SavedBill {
  id: string
  orderNumber: number
  date: string
  customerName: string
  customerLocation: string
  mobileNumber: string
  products: Product[]
  advance: string
  total: number
  balance: number
  savedAt: string
}

export default function BillingApp() {
  const [orderNumber, setOrderNumber] = useState(283)
  const [date, setDate] = useState("17-12-2025")
  const [customerName, setCustomerName] = useState("")
  const [customerLocation, setCustomerLocation] = useState("")
  const [mobileNumber, setMobileNumber] = useState("")

  // Form inputs for adding products
  const [description, setDescription] = useState("")
  const [size, setSize] = useState("")
  const [media, setMedia] = useState("")
  const [ssOrFb, setSsOrFb] = useState("")
  const [colour, setColour] = useState("")
  const [quantity, setQuantity] = useState("")
  const [rate, setRate] = useState("")

  const [products, setProducts] = useState<Product[]>([])
  const [isPrinting, setIsPrinting] = useState(false)

  // Payment details
  const [advance, setAdvance] = useState("")

  const [savedBills, setSavedBills] = useState<SavedBill[]>([])
  const [viewMode, setViewMode] = useState<"create" | "list" | "view">("create")
  const [selectedBill, setSelectedBill] = useState<SavedBill | null>(null)

  const invoiceRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const saved = localStorage.getItem("savedBills")
    if (saved) {
      setSavedBills(JSON.parse(saved))
    }
  }, [])

  const addProduct = () => {
    if (description && quantity && rate) {
      const qty = Number.parseFloat(quantity) || 0
      const rateVal = Number.parseFloat(rate) || 0
      const calculatedAmount = qty * rateVal

      const newProduct: Product = {
        id: Date.now().toString(),
        description,
        size,
        media,
        ssOrFb,
        colour,
        quantity: qty,
        rate: rateVal,
        amount: calculatedAmount,
      }

      setProducts([...products, newProduct])
      // Clear form
      setDescription("")
      setSize("")
      setMedia("")
      setSsOrFb("")
      setColour("")
      setQuantity("")
      setRate("")
    }
  }

  const removeProduct = (id: string) => {
    setProducts(products.filter((p) => p.id !== id))
  }

  const total = products.reduce((sum, product) => sum + product.amount, 0)
  const advanceAmount = Number.parseFloat(advance) || 0
  const balance = total - advanceAmount

  const handlePrint = () => {
    setIsPrinting(true)
    setTimeout(() => {
      window.print()
      setIsPrinting(false)
    }, 100)
  }

  const handleNewBill = () => {
    if (confirm("Are you sure you want to create a new order form? This will clear all current data.")) {
      setOrderNumber(orderNumber + 1)
      setDate(new Date().toLocaleDateString("en-GB").replace(/\//g, "-"))
      setCustomerName("")
      setCustomerLocation("")
      setMobileNumber("")
      setProducts([])
      setAdvance("")
      setViewMode("create")
      setSelectedBill(null)
    }
  }

  const handleSaveBill = () => {
    if (!customerName) {
      alert("Please enter customer name before saving")
      return
    }
    if (products.length === 0) {
      alert("Please add at least one product before saving")
      return
    }

    const newBill: SavedBill = {
      id: Date.now().toString(),
      orderNumber,
      date,
      customerName,
      customerLocation,
      mobileNumber,
      products,
      advance,
      total,
      balance,
      savedAt: new Date().toISOString(),
    }

    const updatedBills = [...savedBills, newBill]
    setSavedBills(updatedBills)
    localStorage.setItem("savedBills", JSON.stringify(updatedBills))
    alert("Bill saved successfully!")
  }

  const handleViewBill = (bill: SavedBill) => {
    setSelectedBill(bill)
    setViewMode("view")
    // Load bill data into current state for viewing/printing
    setOrderNumber(bill.orderNumber)
    setDate(bill.date)
    setCustomerName(bill.customerName)
    setCustomerLocation(bill.customerLocation)
    setMobileNumber(bill.mobileNumber)
    setProducts(bill.products)
    setAdvance(bill.advance)
  }

  const handleDeleteBill = (id: string) => {
    if (confirm("Are you sure you want to delete this bill?")) {
      const updatedBills = savedBills.filter((bill) => bill.id !== id)
      setSavedBills(updatedBills)
      localStorage.setItem("savedBills", JSON.stringify(updatedBills))
    }
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="mx-auto max-w-7xl">
        {/* Header Controls - Hidden when printing */}
        <div className={`mb-4 flex flex-wrap items-center justify-between gap-2 ${isPrinting ? "hidden" : ""}`}>
          <h1 className="text-xl font-bold">Order Form System</h1>
          <div className="flex gap-2">
            {viewMode !== "create" && (
              <Button onClick={() => setViewMode("create")} variant="outline" size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Create New
              </Button>
            )}
            {viewMode !== "list" && (
              <Button onClick={() => setViewMode("list")} variant="outline" size="sm">
                <FolderOpen className="mr-2 h-4 w-4" />
                View Saved Bills ({savedBills.length})
              </Button>
            )}
            {viewMode === "create" && (
              <>
                <Button onClick={handleSaveBill} variant="outline" size="sm">
                  <Save className="mr-2 h-4 w-4" />
                  Save Bill
                </Button>
                <Button onClick={handleNewBill} variant="outline" size="sm">
                  <Plus className="mr-2 h-4 w-4" />
                  New Order
                </Button>
              </>
            )}
            {(viewMode === "create" || viewMode === "view") && (
              <Button onClick={handlePrint} size="sm">
                <Printer className="mr-2 h-4 w-4" />
                Print
              </Button>
            )}
          </div>
        </div>

        {viewMode === "list" && !isPrinting && (
          <div className="rounded-lg border bg-white p-6">
            <h2 className="mb-4 text-lg font-bold">Saved Bills</h2>
            {savedBills.length === 0 ? (
              <p className="py-8 text-center text-muted-foreground">No saved bills yet</p>
            ) : (
              <div className="space-y-2">
                {savedBills
                  .sort((a, b) => new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime())
                  .map((bill) => (
                    <div
                      key={bill.id}
                      className="flex items-center justify-between rounded border p-4 hover:bg-gray-50"
                    >
                      <div className="flex-1">
                        <div className="font-bold">
                          Order #{bill.orderNumber} - {bill.customerName}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Date: {bill.date} | Total: Rs. {bill.total.toLocaleString("en-IN")}/- | Products:{" "}
                          {bill.products.length}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Saved: {new Date(bill.savedAt).toLocaleString()}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={() => handleViewBill(bill)} size="sm" variant="outline">
                          <Eye className="mr-1 h-4 w-4" />
                          View
                        </Button>
                        <Button onClick={() => handleDeleteBill(bill.id)} size="sm" variant="destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}

        {/* Order Form - Show in create or view mode */}
        {(viewMode === "create" || viewMode === "view") && (
          <div className="border-2 border-black bg-white" ref={invoiceRef}>
            {viewMode === "view" && !isPrinting && (
              <div className="bg-blue-100 p-2 text-center text-sm font-medium text-blue-900">
                Viewing Saved Bill - Order #{selectedBill?.orderNumber}
              </div>
            )}

            {/* Header Section */}
            <div className="grid grid-cols-[1fr_auto] border-b-2 border-black">
              {/* Left: Logo and Company Info */}
              <div className="flex items-start gap-4 border-r-2 border-black p-4">
                <div className="flex-shrink-0">
                  <div className="flex h-20 w-20 items-center justify-center">
                    <svg viewBox="0 0 100 100" className="h-full w-full">
                      <path d="M20 30 L50 10 L80 30 L80 50 L50 70 L20 50 Z" fill="black" />
                      <path d="M35 40 L50 30 L65 40 L65 55 L50 65 L35 55 Z" fill="white" />
                    </svg>
                  </div>
                  <div className="mt-1 text-center text-xs font-bold">design world</div>
                  <div className="text-center text-[10px]">designing • printing</div>
                </div>
                <div className="flex-1 pt-1 text-xs leading-tight">
                  <div className="font-medium">5/246, Saleem Building, Opp. Chennai Silks,</div>
                  <div className="font-medium">Junction Main Road, Salem - 635 004.</div>
                  <div className="mt-1 font-bold">Mobile : 7550 911 411, 95668 89055</div>
                  <div className="font-medium">E-mail : designworldsalem@gmail.com</div>
                </div>
              </div>

              {/* Right: Order Form Label */}
              <div className="flex items-start justify-end p-2">
                <div className="px-6 py-2 text-sm font-bold uppercase">Order Form</div>
              </div>
            </div>

            {/* Order Info and Customer Section */}
            <div className="grid grid-cols-[1fr_auto_auto] border-b-2 border-black">
              {/* Customer Details */}
              <div className="border-r-2 border-black p-3">
                <div className="flex items-baseline gap-2">
                  <span className="text-sm font-medium">To :</span>
                  {isPrinting || viewMode === "view" ? (
                    <div>
                      <span className="text-sm font-bold uppercase">{customerName}</span>
                      {customerLocation && <span className="text-sm">, {customerLocation}</span>}
                    </div>
                  ) : (
                    <div className="flex flex-1 gap-2">
                      <Input
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="Customer Name"
                        className="h-7 flex-1 border-gray-300 text-sm"
                      />
                      <Input
                        type="text"
                        value={customerLocation}
                        onChange={(e) => setCustomerLocation(e.target.value)}
                        placeholder="Location"
                        className="h-7 flex-1 border-gray-300 text-sm"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Order Number */}
              <div className="flex items-center border-r-2 border-black p-3">
                <span className="mr-2 text-sm font-medium">Order No. :</span>
                {isPrinting || viewMode === "view" ? (
                  <span className="text-sm font-bold">{orderNumber}</span>
                ) : (
                  <Input
                    type="number"
                    value={orderNumber}
                    onChange={(e) => setOrderNumber(Number.parseInt(e.target.value) || 1)}
                    className="h-7 w-20 border-gray-300 text-sm font-bold"
                  />
                )}
              </div>

              {/* Date */}
              <div className="flex items-center p-3">
                <span className="mr-2 text-sm font-medium">Date :</span>
                {isPrinting || viewMode === "view" ? (
                  <span className="text-sm font-bold">{date}</span>
                ) : (
                  <Input
                    type="text"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    placeholder="DD-MM-YYYY"
                    className="h-7 w-32 border-gray-300 text-sm font-bold"
                  />
                )}
              </div>
            </div>

            {/* Mobile Number Row */}
            <div className="border-b-2 border-black p-3">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Mobile :</span>
                {isPrinting || viewMode === "view" ? (
                  <span className="text-sm">{mobileNumber}</span>
                ) : (
                  <Input
                    type="tel"
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value)}
                    placeholder="Mobile Number"
                    className="h-7 flex-1 border-gray-300 text-sm"
                  />
                )}
              </div>
            </div>

            {/* Add Product Form - Hidden when printing or viewing saved bill */}
            {!isPrinting && viewMode === "create" && (
              <div className="border-b-2 border-black bg-gray-50 p-3">
                <div className="mb-2 text-sm font-bold">Add Product</div>
                <div className="grid grid-cols-7 gap-2">
                  <Input
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Description"
                    className="h-8 text-xs"
                  />
                  <Input
                    value={size}
                    onChange={(e) => setSize(e.target.value)}
                    placeholder="Size"
                    className="h-8 text-xs"
                  />
                  <Input
                    value={media}
                    onChange={(e) => setMedia(e.target.value)}
                    placeholder="Media"
                    className="h-8 text-xs"
                  />
                  <Input
                    value={ssOrFb}
                    onChange={(e) => setSsOrFb(e.target.value)}
                    placeholder="S.S. / F&B"
                    className="h-8 text-xs"
                  />
                  <Input
                    value={colour}
                    onChange={(e) => setColour(e.target.value)}
                    placeholder="Colour"
                    className="h-8 text-xs"
                  />
                  <Input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    placeholder="QTY."
                    className="h-8 text-xs"
                  />
                  <Input
                    type="number"
                    value={rate}
                    onChange={(e) => setRate(e.target.value)}
                    placeholder="Rate"
                    className="h-8 text-xs"
                  />
                </div>
                <Button onClick={addProduct} size="sm" className="mt-2">
                  <Plus className="mr-1 h-3 w-3" />
                  Add
                </Button>
              </div>
            )}

            {/* Products Table */}
            <div className="border-b-2 border-black">
              {/* Table Header */}
              <div
                className={`grid ${viewMode === "view" || isPrinting ? "grid-cols-[2fr_1fr_1fr_1fr_1fr_1fr_1fr]" : "grid-cols-[2fr_1fr_1fr_1fr_1fr_1fr_1fr_auto]"} border-b-2 border-black bg-black text-white`}
              >
                <div className="border-r border-white p-2 text-center text-xs font-bold uppercase">
                  Description of Goods
                </div>
                <div className="border-r border-white p-2 text-center text-xs font-bold uppercase">Size</div>
                <div className="border-r border-white p-2 text-center text-xs font-bold uppercase">Media</div>
                <div className="border-r border-white p-2 text-center text-xs font-bold uppercase">S.S. / F&B</div>
                <div className="border-r border-white p-2 text-center text-xs font-bold uppercase">Colour</div>
                <div className="border-r border-white p-2 text-center text-xs font-bold uppercase">QTY.</div>
                <div
                  className={`p-2 text-center text-xs font-bold uppercase ${viewMode === "create" && !isPrinting ? "border-r border-white" : ""}`}
                >
                  Amount
                </div>
                {!isPrinting && viewMode === "create" && <div className="w-12 p-2"></div>}
              </div>

              {/* Table Body */}
              <div className="min-h-[400px]">
                {products.map((product, index) => (
                  <div
                    key={product.id}
                    className={`grid ${viewMode === "view" || isPrinting ? "grid-cols-[2fr_1fr_1fr_1fr_1fr_1fr_1fr]" : "grid-cols-[2fr_1fr_1fr_1fr_1fr_1fr_1fr_auto]"} border-b border-black`}
                  >
                    <div className="border-r border-black p-2 text-xs font-bold uppercase">{product.description}</div>
                    <div className="border-r border-black p-2 text-center text-xs">{product.size}</div>
                    <div className="border-r border-black p-2 text-center text-xs">{product.media}</div>
                    <div className="border-r border-black p-2 text-center text-xs">{product.ssOrFb}</div>
                    <div className="border-r border-black p-2 text-center text-xs">{product.colour}</div>
                    <div className="border-r border-black p-2 text-center text-xs">{product.quantity}</div>
                    <div
                      className={`p-2 text-right text-xs font-bold ${viewMode === "create" && !isPrinting ? "border-r border-black" : ""}`}
                    >
                      Rs. {product.amount.toLocaleString("en-IN")}/-
                    </div>
                    {!isPrinting && viewMode === "create" && (
                      <div className="flex items-start justify-center p-1">
                        <Button
                          onClick={() => removeProduct(product.id)}
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Total Row */}
              {products.length > 0 && (
                <div className="grid grid-cols-[2fr_1fr_1fr_1fr_1fr_1fr_1fr] border-t-2 border-black">
                  <div className="col-span-5 border-r border-black"></div>
                  <div className="border-r border-black p-2 text-center text-xs font-bold uppercase">Total</div>
                  <div className="p-2 text-right text-xs font-bold">Rs. {total.toLocaleString("en-IN")}/-</div>
                </div>
              )}
            </div>

            {/* Footer Section */}
            <div className="grid grid-cols-[1fr_auto_auto]">
              {/* Conditions */}
              <div className="border-r-2 border-black p-3">
                <div className="mb-2 text-xs font-bold uppercase">Conditions :</div>
                <ul className="space-y-1 text-[10px] leading-tight">
                  <li className="flex gap-1">
                    <span>•</span>
                    <span>Full amount should be paid before delivery</span>
                  </li>
                  <li className="flex gap-1">
                    <span>•</span>
                    <span>
                      Concern will not be responsible for goods not received by the customer after 15 days from delivery
                      date
                    </span>
                  </li>
                  <li className="flex gap-1">
                    <span>•</span>
                    <span>Any alteration and cancellation of order will not be entertain after the proof verified</span>
                  </li>
                  <li className="flex gap-1">
                    <span>•</span>
                    <span>
                      There Will be 10 To 20% of colour variations in the final output comparing to the monitor, mail &
                      digital print.
                    </span>
                  </li>
                  <li className="flex gap-1">
                    <span>•</span>
                    <span>Delivery date may be changed due to uncertain cause</span>
                  </li>
                </ul>
              </div>

              {/* Payment Details */}
              <div className="flex flex-col justify-between border-r-2 border-black p-3">
                <div>
                  <div className="mb-3 text-center text-xs font-bold">Payment Details :</div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="w-16 text-xs font-bold">Total</span>
                      <span className="text-xs">:</span>
                      <span className="text-xs font-medium">Rs. {total.toLocaleString("en-IN")}/-</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-16 text-xs font-bold">Advance</span>
                      <span className="text-xs">:</span>
                      {isPrinting || viewMode === "view" ? (
                        <span className="text-xs font-medium">
                          {advance ? `Rs. ${Number.parseFloat(advance).toLocaleString("en-IN")}/-` : "-"}
                        </span>
                      ) : (
                        <Input
                          type="text"
                          value={advance}
                          onChange={(e) => setAdvance(e.target.value)}
                          placeholder="0"
                          className="h-6 w-32 text-xs"
                        />
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-16 text-xs font-bold">Balance</span>
                      <span className="text-xs">:</span>
                      <span className="text-xs font-medium">Rs. {balance.toLocaleString("en-IN")}/-</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex min-w-[160px] flex-col items-center justify-between p-4">
                <div className="text-xs font-medium">For Design World</div>
                <div className="my-8 w-full border-b-2 border-black"></div>
                <div className="text-xs">Authorised Signatory</div>
              </div>
            </div>

            {/* Bottom Note */}
            <div className="border-t-2 border-black p-2 text-center text-[10px]">
              Thank you for making business with us. © Design World
            </div>
          </div>
        )}
      </div>

      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          body {
            background: white !important;
          }
          .min-h-screen {
            padding: 0 !important;
            margin: 0 !important;
          }
          .max-w-7xl {
            max-width: 100% !important;
            padding: 10mm !important;
          }
          button {
            display: none !important;
          }
          @page {
            size: A4;
            margin: 0;
          }
        }
      `}</style>
    </div>
  )
}
